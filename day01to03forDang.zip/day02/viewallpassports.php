/* Once you have above implemented create viewallpassports.php file which will display a table with id, passportNo and the image columns showing all data of passports table.
You can set width of img tag to 150 pixels.
*/