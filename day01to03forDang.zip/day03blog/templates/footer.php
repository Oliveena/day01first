<style>.footer-section {
    background-color: #E2ECE9;
    padding: 20px 0;
    text-align: center;
    margin-top: 40px;
    /*border-top: 2px solid #FAD2E1;*/
}

.footer-container {
    color: #84A4FC;
    max-width: 960px;
    margin: 0 auto;
    padding: 20px;
}

.footer-section p {
    font-size: 14px;
    margin: 0;
}</style>

<footer class="footer-section">
    <div class="footer-container">
        <p>&copy; 2025 Oliveena. All rights reserved.</p>
    </div>
</footer>

</body>
